import java.util.Scanner;

class Voto {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int idade;

        System.out.print("Qual a sua idade? ");
        idade = entrada.nextInt();

        if (idade < 16) {
            System.out.println("Desculpe, mas você ainda não tem idade para votar...");
        } else if (idade <= 17 || idade > 65) {
            System.out.println("O seu voto é facultativo, você pode votar se desejar.");
        } else {
            System.out.println("Você precisa votar, o seu voto é obrigatório.");
        }

        entrada.close();
    }
}