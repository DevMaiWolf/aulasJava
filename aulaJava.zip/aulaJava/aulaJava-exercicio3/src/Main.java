import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Escreva o seu primeiro número:");
        int numero1 = scanner.nextInt();
        System.out.println("Escreva o seu segundo número:");
        int numero2 = scanner.nextInt();
        System.out.println("Escreva o seu terceiro número:");
        int numero3 = scanner.nextInt();

        int maior = numero1;
        int menor = numero1;
        if (numero2 > maior) {
            maior = numero2;
        }
        if (numero3 > maior) {
            maior = numero3;
        }
        if (numero2 < menor) {
            menor = numero2;
        }
        if (numero3 < menor) {
            menor = numero3;
        }

        double media = (double) (numero1 + numero2 + numero3) / 3;
        double mediaArredondada = (double) Math.round(media * 100) / 100;

        System.out.println("O maior número que você escreveu é " + maior);
        System.out.println("O menor número que você escreveu é " + menor);
        System.out.println("Enquanto a média aritmética é " + mediaArredondada);
    }
}