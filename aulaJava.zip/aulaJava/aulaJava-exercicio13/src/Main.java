import java.util.Scanner;

class MetadeDaPalavra {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Escreva a palavra desejada: ");
        String palavra = entrada.nextLine();
        int meio = palavra.length();
        String meiaPalavra = palavra.substring(0, meio/2);
        System.out.println("A primeira metade da palavra inserida é: " + meiaPalavra);
        entrada.close();
    }
}