import java.util.Scanner;

class PalavraReversa {
    public static void main(String[] args) {
        Scanner palavra = new Scanner(System.in);
        System.out.println("Escreva a sua palavra: ");
        String escrita = palavra.nextLine();
        StringBuilder escrito = new StringBuilder(escrita);
        escrito.reverse();
        System.out.println("O reverso da sua palavra é: " + escrito);
        palavra.close();
    }
}