import java.util.Scanner;

class PrioridadeNaFila {
    public static void main(String[] args) {
        Scanner entreda = new Scanner(System.in);
        String nome;
        int opcao;

        System.out.print("Qual é o seu nome?");
        nome = entreda.nextLine();

        System.out.println("Olá, " + nome + "!" + " Observe as opções abaixo e escolha aquela que se enquadra na sua condição:");
        System.out.println("0 - Nenhuma das alternativas");
        System.out.println("1 - Gestante");
        System.out.println("2 - Idosa");
        System.out.println("3 - Deficiente");
        System.out.print("Escolha a sua opção: ");
        opcao = Integer.parseInt(entreda.next());

        if (opcao == 1 || opcao == 2 || opcao == 3) {
            System.out.println("Muito bem," + nome + "!" + " Você tem direito a fila prioritária.");
        } else {
            System.out.println("Desculpe, " + nome + "," + " você não tem direito a fila prioritária.");
        }

        entreda.close();
    }
}