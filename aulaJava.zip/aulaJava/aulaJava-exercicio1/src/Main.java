//Exercício 01
//Crie um programa que leia seu nome e imprima na tela.
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite aqui o seu nome:");
        String nome = scanner.nextLine();
        System.out.println("Olá, " + nome + ", continue firme na sua caminhada do conhecimento!");
    }
}