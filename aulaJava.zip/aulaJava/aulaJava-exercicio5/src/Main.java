import java.util.Scanner;

class Horario {
    public static void main(String[] args) {
        Scanner escrito = new Scanner(System.in);
        int hora, minuto, segundo;
        int horasPassadas, horasFaltantes;

        System.out.print("Escreva apenas a hora: ");
        hora = escrito.nextInt();
        System.out.print("Escreva apenas o minuto: ");
        minuto = escrito.nextInt();
        System.out.print("Escreva apenas o segundo: ");
        segundo = escrito.nextInt();

        horasPassadas = segundo + minuto*60 + hora*3600;
        horasFaltantes = 86400 - horasPassadas;

        System.out.println("Desde as 0h 00min 0s, já se passaram: " + horasPassadas + " segundos.");
        System.out.println("Logo, para a meia-noite, faltam: " + horasFaltantes + " segundos.");

        escrito.close();
    }
}