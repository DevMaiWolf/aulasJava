import java.util.Scanner;

class Consorcio {
    public static void main(String[] args) {
        Scanner inserido = new Scanner(System.in);
        int idade;
        double salario;

        System.out.print("Por favor, informe a sua idade: ");
        idade = inserido.nextInt();
        System.out.print("Agora, informe qual a sua renda: ");
        salario = inserido.nextDouble();

        if (idade >= 18 && salario > 2000) {
            System.out.println("Muito bem! Você está habilitado para comprar um automóvel.");
        } else {
            System.out.println("Desculpe, você não está habilitado para comprar um automóvel.");
        }

        inserido.close();
    }
}