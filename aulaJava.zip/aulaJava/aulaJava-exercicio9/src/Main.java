import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class NumerosPrimos {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o seu primeiro número: ");
        int numero1 = scanner.nextInt();

        System.out.print("Digite o segundo número: ");
        int numero2 = scanner.nextInt();

        List<Integer> primos = new ArrayList<>();
        List<Integer> naoPrimos = new ArrayList<>();

        System.out.println("Resultados:");

        for (int entrada = numero1; entrada <= numero2; entrada++) {
            if (verificarPrimo(entrada)) {
                primos.add(entrada);
            } else {
                naoPrimos.add(entrada);
            }
        }

        System.out.println("No intervalo entre os números que você digitou, esses são primos:");
        for (int primo : primos) {
            System.out.println(primo);
        }

        System.out.println("No intervalo entre os números que você digitou, esses NÃO são primos:");
        for (int naoPrimo : naoPrimos) {
            System.out.println(naoPrimo);
        }

        scanner.close();
    }
// Essa função verifica se o númeoro é primo.
    public static boolean verificarPrimo(int digitado) {
        if (digitado <= 1) {
            return false;
        } else {
            for (int entrada = 2; entrada * entrada <= digitado; entrada++) {
                if (digitado % entrada == 0) {
                    return false;
                }
            }
            return true;
        }
    }
}

