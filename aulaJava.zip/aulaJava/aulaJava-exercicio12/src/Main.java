import java.util.Scanner;

class Calculator {
    public static void main(String[] args) {
        Scanner valor = new Scanner(System.in);
        char operador;
        double numero1, numero2, resultado = 0;
        do {
            System.out.println("Informe dois números, um de cada vez, seguido da tecla enter: ");
            numero1 = valor.nextDouble();
            numero2 = valor.nextDouble();
            System.out.println("Escolha o operador (+, -, *, /): ");
            operador = valor.next().charAt(0);
            if (operador == '+' || operador == '-' || operador == '*' || operador == '/') {
                switch (operador) {
                    case '+':
                        resultado = numero1 + numero2;
                        break;
                    case '-':
                        resultado = numero1 - numero2;
                        break;
                    case '*':
                        resultado = numero1 * numero2;
                        break;
                    case '/':
                        resultado = numero1 / numero2;
                        break;
                }
                System.out.println(numero1 + " " + operador + " " + numero2 + " = " + resultado);
                         } else {    System.out.println("Desculpe, você escolheu um operador inválido, tente novamente!");
                         break;
            }
            System.out.println("O  cálculo executado é: " + numero1 + " " + operador + " " + numero2 + " = " + resultado);
            System.out.println("Você gostaria de continuar? (s/n)");
        } while (valor.next().charAt(0) == 's');
        valor.close();
    }
}