import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        double salarioMinimo = 1320;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Informe o seu salário:");
        double salarioInformado = scanner.nextDouble();

        double quantidadeSalariosMinimos = salarioInformado / salarioMinimo;
        double quantidadeSalariosMinimosArredondada = (double) Math.round(quantidadeSalariosMinimos * 100) / 100;

        System.out.println("Você recebe " + quantidadeSalariosMinimosArredondada + " salários mínimos.");
    }
}